import java.util.Date;

public abstract class Staff implements ICalculator {
    private String id;
    private String name;
    private int age;
    private double salaryCoefficient;
    private Date startingDate;
    private Department dept;
    private int numAL;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public double getSalaryCoefficient() {
        return salaryCoefficient;
    }

    public void setSalaryCoefficient(double salaryCoefficient) {
        this.salaryCoefficient = salaryCoefficient;
    }

    public Date getStartingDate() {
        return startingDate;
    }

    public void setStartingDate(Date startingDate) {
        this.startingDate = startingDate;
    }

    public Department getDept() {
        return dept;
    }

    public void setDept(Department dept) {
        this.dept = dept;
    }

    public int getNumAL() {
        return numAL;
    }

    public void setNumAL(int numAL) {
        this.numAL = numAL;
    }

    public abstract void displayInformation();

}
