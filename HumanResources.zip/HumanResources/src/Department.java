public class Department {
    private String deptCode;
    private String deptName;
    private int numStaff;


    public Department(String deptCode) {
        this.deptCode = deptCode;
    }

    public Department(String deptCode, int numStaff) {
        this.deptCode = deptCode;
        this.numStaff = numStaff;
    }

    public String getDeptCode() {
        return deptCode;
    }

    public void setDeptCode(String deptCode) {
        this.deptCode = deptCode;
    }

    public String getDeptName() {
        return deptName;
    }

    public void setDeptName(String deptName) {
        this.deptName = deptName;
    }

    public int getNumStaff() {
        return numStaff;
    }

    public void setNumStaff(int numStaff) {
        this.numStaff = numStaff;
    }

    public String toString() {
        return String.format("%-20s%-15d", this.getDeptCode(), this.getNumStaff());
    }


}
