import java.text.SimpleDateFormat;

public class Manager extends Staff {
    private String position;

    public Manager() {
    }

    public String getPosition() {
        return position;
    }

    public void setPosition(String position) {
        this.position = position;
    }

    @Override
    public void displayInformation() {
        SimpleDateFormat df = new SimpleDateFormat("dd/MM/yyyy");
        System.out.printf("%-10s%-25s%-8d%-23.1f%-18s%-16s%-18d%-15s%-20s", this.getId(), this.getName(), this.getAge(),
                this.getSalaryCoefficient(), df.format(this.getStartingDate()), this.getDept().getDeptCode(), this.getNumAL(), "", this.getPosition());
    }

    @Override
    public double calculateSalary() {
        double salary;
        double responsible;
        switch (this.getPosition().toLowerCase()) {
            case "business leader":
                responsible = 8000000;
                break;
            case "project leader":
                responsible = 5000000;
                break;
            case "technical leader":
                responsible = 6000000;
                break;
            default:
                responsible = 0;
        }
        salary = this.getSalaryCoefficient() * 5000000 + responsible;
        return salary;
    }
}
