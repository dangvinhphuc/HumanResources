import java.text.SimpleDateFormat;

public class Employee extends Staff {
    private int overTime;

    public Employee() {
    }

    public int getOverTime() {
        return overTime;
    }

    public void setOverTime(int overTime) {
        this.overTime = overTime;
    }

    @Override
    public void displayInformation() {
        SimpleDateFormat df = new SimpleDateFormat("dd/MM/yyyy");
        System.out.printf("%-10s%-25s%-8d%-23.1f%-18s%-16s%-18d%-15d%-20s", this.getId(), this.getName(), this.getAge(),
                this.getSalaryCoefficient(), df.format(this.getStartingDate()), this.getDept().getDeptCode(), this.getNumAL(), this.getOverTime(), "(Employee)");
    }

    @Override
    public double calculateSalary() {
        double salary = this.getSalaryCoefficient() * 3000000 + this.getOverTime() * 200000;
        return salary;
    }
}
