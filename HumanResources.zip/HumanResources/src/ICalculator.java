public interface ICalculator {
    public double calculateSalary();
}
