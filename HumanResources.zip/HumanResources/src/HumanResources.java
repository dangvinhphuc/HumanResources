import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;

public class HumanResources {
    public static int functionSelect;
    public static int confirm = 1;
    public static List<Staff> staffs = new ArrayList<>();
    public static List<Department> departments = new ArrayList<>();

    public static void main(String[] args) {
        System.out.println("WELCOME TO HUMAN RESOURCES MANAGER PROGRAM");
        while (confirm == 1) {
            menu();
            if (functionSelect == 8) {
                confirm = 2;
            } else {
                switch (functionSelect) {
                    case 1:
                        addStaff();
                        break;
                    case 2:
                        displayDept();
                        break;
                    case 3:
                        displayAllStaff();
                        break;
                    case 4:
                        displayStaffByDept();
                        break;
                    case 5:
                        searchStaff();
                        break;
                    case 6:
                        displaySalary();
                        break;
                    case 7:
                        deleteStaff();
                        break;
                }
                confirmContinue();
            }
        }
        System.out.println("Thanks!");
    }

    private static void menu() {
        System.out.println("1. ADD NEW STAFF");
        System.out.println("2. DISPLAY DEPARTMENT");
        System.out.println("3. DISPLAY ALL STAFF");
        System.out.println("4. DISPLAY STAFF BY DEPARTMENT");
        System.out.println("5. SEARCH STAFF");
        System.out.println("6. DISPLAY SALARY");
        System.out.println("7. DELETE STAFF");
        System.out.println("8. EXIT\n");
        System.out.print("Please select function: ");
        functionSelect = inputInt();
        while (functionSelect < 1 || functionSelect > 8) {
            System.out.println("Please enter 1-8");
            functionSelect = inputInt();
        }
    }

    private static void addStaff() {
        int chooseToAdd;
        System.out.println("Select type of Staff to add:");
        System.out.println("1: EMPLOYEE");
        System.out.println("2: MANAGEMENT");
        chooseToAdd = inputInt();
        while (chooseToAdd < 1 || chooseToAdd > 2) {
            System.out.println("Please choose 1 (EMPLOYEE) or 2 (MANAGEMENT) to add");
            chooseToAdd = inputInt();
        }
        if (chooseToAdd == 1) {
            addEmployee();
        } else {
            addManager();
        }
    }

    private static void addEmployee() {
        Employee newEmployee = new Employee();
        System.out.print("Input ID: ");
        newEmployee.setId(inputString());
        System.out.print("Input name: ");
        newEmployee.setName(inputString());
        System.out.print("Input age: ");
        newEmployee.setAge(inputInt());
        System.out.print("Input salary coefficient: ");
        newEmployee.setSalaryCoefficient(inputDouble());
        System.out.print("Input starting date: ");
        newEmployee.setStartingDate(inputDate());
        System.out.print("Input department: ");
        newEmployee.setDept(new Department(inputString(), 1));
        System.out.print("Input number of AL: ");
        newEmployee.setNumAL(inputInt());
        System.out.print("Input overtime hours: ");
        newEmployee.setOverTime(inputInt());
        System.out.println("Do you want to add a new Employee to the list?");
        System.out.println("1: YES");
        System.out.println("2: NO");
        int confirm = inputInt();
        while (confirm < 1 || confirm > 2) {
            System.out.println("Please choose 1 (YES) or 2 (NO)");
            confirm = inputInt();
        }
        if (confirm == 1) {
            staffs.add(newEmployee);
            addDeptList(newEmployee.getDept());//thêm thông tin bộ phận vào danh sách quản lý
            System.out.println("You have successfully added!");
        }
    }

    private static void addManager() {
        Manager newManager = new Manager();
        System.out.print("Input ID: ");
        newManager.setId(inputString());
        System.out.print("Input name: ");
        newManager.setName(inputString());
        System.out.print("Input age: ");
        newManager.setAge(inputInt());
        System.out.print("Input salary coefficient: ");
        newManager.setSalaryCoefficient(inputDouble());
        System.out.print("Input starting date: ");
        newManager.setStartingDate(inputDate());
        System.out.print("Input department: ");
        newManager.setDept(new Department(inputString(), 1));
        System.out.print("Input number of AL: ");
        newManager.setNumAL(inputInt());

        int position;
        System.out.println("Select position: ");
        System.out.println("1: Business Leader");
        System.out.println("2: Project Leader");
        System.out.println("3: Technical Leader");
        position = inputInt();
        while (position < 1 || position > 3) {
            System.out.print("Please choose from 1 to 3: ");
            position = inputInt();
        }
        switch (position) {
            case 1:
                newManager.setPosition("Business Leader");
                break;
            case 2:
                newManager.setPosition("Project Leader");
                break;
            case 3:
                newManager.setPosition("Technical Leader");
                break;
        }
        System.out.println("Do you want to add a new Manager to the list?");
        System.out.println("1: YES");
        System.out.println("2: NO");
        int confirm = inputInt();
        while (confirm < 1 || confirm > 2) {
            System.out.println("Please choose 1 (YES) or 2 (NO)");
            confirm = inputInt();
        }
        if (confirm == 1) {
            staffs.add(newManager);
            addDeptList(newManager.getDept());//thêm thông tin bộ phận vào danh sách quản lý
            System.out.println("You have successfully added!");
        }
    }

    private static void displayDept() {
        if (departments.isEmpty()) {
            System.out.println("No information. Please add Staff to the list!");
        } else {
            System.out.printf("%-10s%-20s%-15s", "Ordinal", "Department", "Number of Staff");
            System.out.println();
            for (int i = 0; i < departments.size(); i++) {
                System.out.printf("%-10d", i + 1);
                System.out.println(departments.get(i).toString());
            }
        }
    }

    private static void displayAllStaff() {
        if (staffs.isEmpty()) {
            System.out.println("No information. Please add Staff to the list!");
        } else {
            System.out.printf("%-12s%-10s%-25s%-8s%-23s%-18s%-16s%-18s%-15s%-20s", "Ordinal", "ID", "Name", "Age",
                    "Salary Coefficient", "Starting Date", "Department", "Number of AL", "Over Time", "Position");
            System.out.println();
            for (int i = 0; i < staffs.size(); i++) {
                System.out.printf("%-12d", i + 1);
                staffs.get(i).displayInformation();
                System.out.println();
            }
        }
    }

    private static void displayStaffByDept() {
        if (staffs.isEmpty()) {
            System.out.println("No information. Please add Staff to the list!");
        } else {
            System.out.printf("%-12s%-10s%-25s%-8s%-23s%-18s%-16s%-18s%-15s%-20s", "Ordinal", "ID", "Name", "Age",
                    "Salary Coefficient", "Starting Date", "Department", "Number of AL", "Over Time", "Position");
            System.out.println();
            int ordinal = 0;
            for (int i = 0; i < departments.size(); i++) {
                for (int j = 0; j < staffs.size(); j++) {
                    if (staffs.get(j).getDept().getDeptCode().equalsIgnoreCase(departments.get(i).getDeptCode())) {
                        ordinal++;
                        System.out.printf("%-12d", ordinal);
                        staffs.get(j).displayInformation();
                        System.out.println();
                    }
                }
            }
        }
    }

    private static void searchStaff() {
        String search;
        List<Staff> staffIndex = new ArrayList<Staff>();
        System.out.print("Input Staff ID/Name to search: ");
        search = inputString().toLowerCase();
        for (int i = 0; i < staffs.size(); i++) {
            if (staffs.get(i).getName().toLowerCase().contains(search) || staffs.get(i).getId().toLowerCase().contains(search)) {
                staffIndex.add(staffs.get(i));
            }
        }
        if (staffIndex.isEmpty()) {
            System.out.println("No results found!");
        } else {
            System.out.printf("%-12s%-10s%-25s%-8s%-23s%-18s%-16s%-18s%-15s%-20s", "Ordinal", "ID", "Name", "Age", "Salary Coefficient",
                    "Starting Date", "Department", "Number of AL", "Over Time", "Position");
            System.out.println();

            for (int i = 0; i < staffIndex.size(); i++) {
                System.out.printf("%-12d", i + 1);
                staffIndex.get(i).displayInformation();
                System.out.println();
            }
        }
    }

    private static void displaySalary() {
        if (staffs.isEmpty()) {
            System.out.println("No information. Please add Staff to the list!");
        } else {
            int sortType;
            List<Staff> staffBySalary = new ArrayList<Staff>();
            staffBySalary.addAll(staffs);//copy danh danh sách staff sang list mới để xử lý (tránh ảnh hưởng list gốc)
            System.out.println("1: Ascending");
            System.out.println("2: Descending");
            sortType = inputInt();
            while (sortType < 1 || sortType > 2) {
                System.out.println("Please choose 1 (Ascending) or 2 (Descending)");
                sortType = inputInt();
            }
            if (sortType == 1) {//sắp xếp danh sách tăng dần
                for (int i = 0; i < staffBySalary.size() - 1; i++) {
                    for (int j = i + 1; j < staffBySalary.size(); j++) {
                        if (staffBySalary.get(j).calculateSalary() < staffBySalary.get(i).calculateSalary()) {
                            staffBySalary.add(j + 1, staffBySalary.get(i));
                            staffBySalary.set(i, staffBySalary.get(j));
                            staffBySalary.remove(j);
                        }
                    }
                }
            } else {//sắp xếp danh sách giảm dần
                for (int i = 0; i < staffBySalary.size() - 1; i++) {
                    for (int j = i + 1; j < staffBySalary.size(); j++) {
                        if (staffBySalary.get(j).calculateSalary() > staffBySalary.get(i).calculateSalary()) {
                            staffBySalary.add(j + 1, staffBySalary.get(i));
                            staffBySalary.set(i, staffBySalary.get(j));
                            staffBySalary.remove(j);
                        }
                    }
                }
            }
            System.out.printf("%-12s%-10s%-25s%-8s%-23s%-18s%-16s%-18s%-15s%-20s%-15s", "Ordinal", "ID", "Name", "Age",
                    "Salary Coefficient", "Starting Date", "Department", "Number of AL", "Over Time", "Position", "Salary");
            System.out.println();
            for (int i = 0; i < staffBySalary.size(); i++) {
                System.out.printf("%-12d", i + 1);
                staffBySalary.get(i).displayInformation();
                System.out.printf("%-15.0f", staffBySalary.get(i).calculateSalary());
                System.out.println();
            }
        }
    }

    private static void deleteStaff() {
        if (staffs.isEmpty()) {
            System.out.println("List is empty!");
        } else {
            displayAllStaff();
            int deleteType;
            System.out.println("1: Delete one by one");
            System.out.println("2: Delete ALL");
            deleteType = inputInt();
            while (deleteType < 1 || deleteType > 2) {
                System.out.println("Please choose 1 (Delete one by one) or 2 (Delete ALL)");
                deleteType = inputInt();
            }
            if (deleteType == 1) {
                int continueDelete = 1;
                while (continueDelete == 1) {
                    int selectDelete;
                    System.out.print("Please enter the ordinal of the Staff you want to delete: ");
                    selectDelete = inputInt();
                    while (selectDelete < 1 || selectDelete > staffs.size()) {
                        System.out.println("Please input from 1 to " + staffs.size());
                        selectDelete = inputInt();
                    }
                    System.out.println("Are you sure?");
                    System.out.println("1: YES");
                    System.out.println("2: NO");
                    int confirm = inputInt();
                    while (confirm < 1 || confirm > 2) {
                        System.out.println("Please choose 1 (YES) or 2 (NO)");
                        confirm = inputInt();
                    }
                    if (confirm == 1) {
                        subDeptList(staffs.get(selectDelete - 1).getDept());//loại bỏ thông tin bộ phận ra khỏi danh sách quản lý
                        staffs.remove(selectDelete - 1);
                        System.out.println("Staff at " + selectDelete + "deleted!");
                        displayAllStaff();
                    }
                    System.out.println("Do you want to continue deleting?");
                    System.out.println("1: YES");
                    System.out.println("2: NO");
                    continueDelete = inputInt();
                    while (continueDelete < 1 || continueDelete > 2) {
                        System.out.println("Please choose 1 (YES) or 2 (NO)");
                        continueDelete = inputInt();
                    }
                }

            } else {
                System.out.println("Are you sure?");
                System.out.println("1: YES");
                System.out.println("2: NO");
                int confirm = inputInt();
                while (confirm < 1 || confirm > 2) {
                    System.out.println("Please choose 1 (YES) or 2 (NO)");
                    confirm = inputInt();
                }
                if (confirm == 1) {
                    while (staffs.size() > 0) {
                        staffs.remove(0);
                    }
                    delAllDeptList();//loại bỏ toàn bộ bộ phận ra khỏi danh sách quản lý
                    System.out.println("All Staff deleted!");
                }
            }
        }
    }

    private static void confirmContinue() {
        System.out.println("Do you want to continue use program?");
        System.out.println("1: YES");
        System.out.println("2: NO");
        confirm = inputInt();
        while (confirm < 1 || confirm > 2) {
            System.out.println("Please choose 1 (YES) or 2 (NO)");
            confirm = inputInt();
        }

    }

    private static int inputInt() {
        Scanner sc = new Scanner(System.in);
        int input;
        while (true) {
            try {
                input = Integer.parseInt(sc.nextLine());
                break;
            } catch (Exception e) {
                System.out.println("Please enter Integer");
            }
        }
        return input;
    }

    private static double inputDouble() {
        Scanner sc = new Scanner(System.in);
        double input;
        while (true) {
            try {
                input = Double.parseDouble(sc.nextLine());
                break;
            } catch (Exception e) {
                System.out.println("Please enter Double");
            }
        }
        return input;
    }

    private static Date inputDate() {
        Scanner sc = new Scanner(System.in);
        SimpleDateFormat df = new SimpleDateFormat("dd/MM/yyyy");
        Date input = null;
        while (true) {
            try {
                input = df.parse(sc.nextLine());
                break;
            } catch (ParseException e) {
                System.out.println("Please enter dd/MM/yyyy");
            }
        }
        return input;

    }

    private static String inputString() {
        Scanner sc = new Scanner(System.in);
        String input = sc.nextLine();
        return input;
    }

    private static void addDeptList(Department dept) {
        String deptName = dept.getDeptCode();
        int numStaff = dept.getNumStaff();
        int size = departments.size();
        if (size == 0) {
            departments.add(dept);
        } else {
            int check = 0;
            for (int i = 0; i < size; i++) {
                if (departments.get(i).getDeptCode().equalsIgnoreCase(deptName)) {//kiểm tra tên bộ phận đã tồn tại trong dánh sách chưa
                    departments.get(i).setNumStaff(departments.get(i).getNumStaff() + numStaff);
                    check = 1;
                }
            }
            if (check == 0) {//thêm thông tin bộ phận mới nếu tên chưa tồn tại trong danh sách
                departments.add(dept);
            }
        }
    }

    private static void subDeptList(Department dept) {
        String deptName = dept.getDeptCode();
        for (int i = 0; i < departments.size(); i++) {
            if (departments.get(i).getDeptCode().equalsIgnoreCase(deptName)) {
                departments.get(i).setNumStaff(departments.get(i).getNumStaff() - 1);//giảm số lượng nhân viên nếu có tên bộ phận trong danh sách quản lý
                if (departments.get(i).getNumStaff() == 0) {
                    departments.remove(i);
                }
            }
        }
    }

    private static void delAllDeptList() {
        while (departments.size() > 0) {
            departments.remove(0);
        }
    }


}
